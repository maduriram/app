﻿# no-waste-of-food

Summer 2021 React-native Final Project
All of the contents are under the Main branch

## Table of contents
* [Setup](#technologies)

## Technologies
Project is created with:
* React-native
* Expo
* Firebase
	
## Setup
To run this project, install it locally using react-native:

```
$ cd ./no-waste-of-food
$ yarn install or npm install
$ yarn start or expo start
and press a to android i to ios
```

## Teammates
* Jiyoung Yoon
* Kareem Bishi
* Maduri Ramadoss

## Youtube Link
* https://youtu.be/G6egj2c09KU

