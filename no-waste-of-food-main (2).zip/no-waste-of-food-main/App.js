import React from 'react';

import Routes from './navigation/index';

export default function App() {
  return <Routes />;
}
